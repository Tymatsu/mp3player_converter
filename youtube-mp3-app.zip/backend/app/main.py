from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from .routers import youtube, downloads

# Create app
app = FastAPI(
    title="YouTube to MP3 Converter",
    description="A sleek, high-performance web application to download YouTube videos as MP3 files",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(youtube.router)
app.include_router(downloads.router)

# Create downloads directory if it doesn't exist
DOWNLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'downloads')
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

@app.get("/")
async def read_root():
    return {"message": "YouTube to MP3 Converter API"}
