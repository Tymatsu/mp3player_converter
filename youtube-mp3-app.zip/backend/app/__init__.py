# Initialize the FastAPI application package
