from pydantic import BaseModel, HttpUrl
from typing import Optional, List
from enum import Enum
import datetime

class DownloadStatus(str, Enum):
    PROCESSING = "processing"
    DOWNLOADING = "downloading"
    COMPLETED = "completed"
    FAILED = "failed"

class YouTubeURL(BaseModel):
    url: HttpUrl

class VideoInfo(BaseModel):
    id: str
    title: str
    thumbnail: str
    url: str
    duration: int
    author: str

class DownloadInfo(BaseModel):
    id: str
    title: str
    thumbnail: str
    url: str
    download_path: str
    timestamp: str
    status: DownloadStatus
    progress: Optional[int] = 0
