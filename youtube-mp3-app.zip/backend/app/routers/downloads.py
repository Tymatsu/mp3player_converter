from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import FileResponse
import os
from ..utils.youtube import DOWNLOAD_DIR

router = APIRouter(prefix="/api", tags=["downloads"])

@router.get("/downloads/{filename}")
async def get_file(filename: str):
    """
    Get a downloaded file
    """
    file_path = os.path.join(DOWNLOAD_DIR, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="audio/mpeg"
    )
