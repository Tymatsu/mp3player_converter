from fastapi import APIRouter, HTTPException, BackgroundTasks, Depends
from ..models.schemas import YouTubeURL, VideoInfo, DownloadInfo
from ..utils.youtube import validate_youtube_url, start_download, get_download_status, get_download_history

router = APIRouter(prefix="/api", tags=["youtube"])

@router.post("/validate", response_model=VideoInfo)
async def validate_url(youtube_url: YouTubeURL):
    """
    Validate a YouTube URL and return video information
    """
    video_info = await validate_youtube_url(str(youtube_url.url))
    if not video_info:
        raise HTTPException(status_code=400, detail="Invalid YouTube URL")
    return video_info

@router.post("/download", response_model=DownloadInfo)
async def download_mp3(youtube_url: YouTubeURL):
    """
    Start downloading a YouTube video as MP3
    """
    download_info = await start_download(str(youtube_url.url))
    if not download_info:
        raise HTTPException(status_code=500, detail="Failed to start download")
    return download_info

@router.get("/status/{download_id}", response_model=DownloadInfo)
async def get_status(download_id: str):
    """
    Get the status of a download
    """
    download_info = get_download_status(download_id)
    if not download_info:
        raise HTTPException(status_code=404, detail="Download not found")
    return download_info

@router.get("/history", response_model=list[DownloadInfo])
async def get_history():
    """
    Get the download history
    """
    return get_download_history()
