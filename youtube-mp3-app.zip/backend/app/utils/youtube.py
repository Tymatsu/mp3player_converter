import os
import logging
from pytube import YouTube
from typing import Optional
import uuid
import datetime
import asyncio
from ..models.schemas import VideoInfo, DownloadInfo, DownloadStatus

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create downloads directory if it doesn't exist
DOWNLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'downloads')
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# Store download history
download_history = []
active_downloads = {}

async def validate_youtube_url(url: str) -> Optional[VideoInfo]:
    """
    Validate a YouTube URL and return video information
    """
    try:
        # Initialize YouTube object
        yt = YouTube(url)
        
        # Return video info
        return VideoInfo(
            id=yt.video_id,
            title=yt.title,
            thumbnail=yt.thumbnail_url,
            url=url,
            duration=yt.length,
            author=yt.author
        )
    except Exception as e:
        logger.error(f"Error validating YouTube URL: {str(e)}")
        return None

async def process_download(download_id: str, url: str) -> None:
    """
    Process a YouTube download in the background
    """
    try:
        # Find download info in active downloads
        download_info = active_downloads.get(download_id)
        if not download_info:
            logger.error(f"Download info not found for ID: {download_id}")
            return
        
        # Update status
        download_info.status = DownloadStatus.PROCESSING
        download_info.progress = 10
        
        # Initialize YouTube object
        yt = YouTube(url)
        
        # Get audio stream
        audio_stream = yt.streams.filter(only_audio=True).first()
        
        # Update progress
        download_info.progress = 30
        
        # Download the audio
        output_file = audio_stream.download(output_path=DOWNLOAD_DIR, filename=f"{download_id}")
        
        # Update progress
        download_info.progress = 70
        
        # Convert to mp3 (rename file extension)
        base, _ = os.path.splitext(output_file)
        mp3_file = f"{base}.mp3"
        os.rename(output_file, mp3_file)
        
        # Update status
        download_info.status = DownloadStatus.COMPLETED
        download_info.progress = 100
        
        # Add to history if not already there
        if download_id not in [item.id for item in download_history]:
            download_history.append(download_info)
        
    except Exception as e:
        logger.error(f"Error processing download: {str(e)}")
        if download_info:
            download_info.status = DownloadStatus.FAILED
            download_info.progress = 0

async def start_download(url: str) -> Optional[DownloadInfo]:
    """
    Start a YouTube download and return download info
    """
    try:
        # Generate a unique ID for this download
        download_id = str(uuid.uuid4())
        
        # Initialize YouTube object
        yt = YouTube(url)
        
        # Create download info
        download_info = DownloadInfo(
            id=download_id,
            title=yt.title,
            thumbnail=yt.thumbnail_url,
            url=url,
            download_path=f"/api/downloads/{download_id}.mp3",
            timestamp=datetime.datetime.now().isoformat(),
            status=DownloadStatus.PROCESSING,
            progress=0
        )
        
        # Add to active downloads
        active_downloads[download_id] = download_info
        
        # Start download in background
        asyncio.create_task(process_download(download_id, url))
        
        return download_info
    except Exception as e:
        logger.error(f"Error starting download: {str(e)}")
        return None

def get_download_status(download_id: str) -> Optional[DownloadInfo]:
    """
    Get the status of a download
    """
    # Check active downloads first
    if download_id in active_downloads:
        return active_downloads[download_id]
    
    # Check download history
    for item in download_history:
        if item.id == download_id:
            return item
    
    return None

def get_download_history() -> list[DownloadInfo]:
    """
    Get the download history
    """
    return download_history
