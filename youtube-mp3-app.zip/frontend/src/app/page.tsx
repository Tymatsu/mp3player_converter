'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { toast } from "sonner"
import { ThemeToggle } from "@/components/theme-toggle"
import { HistorySection } from "@/components/history-section"
import { useAppStore } from "@/lib/store"
import { useValidateUrl, useStartDownload, useDownloadStatus, useDownloadHistory } from "@/lib/api-hooks"
import { useTheme } from 'next-themes'
import { useEffect } from 'react'

// Animation variants
const fadeIn = {
  hidden: { opacity: 0 },
  visible: { 
    opacity: 1,
    transition: { duration: 0.5 }
  }
}

const slideUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { 
      type: "spring", 
      stiffness: 300, 
      damping: 24 
    }
  }
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
}

export default function Home() {
  // Get state from Zustand store
  const { 
    url, 
    setUrl, 
    videoInfo, 
    setVideoInfo, 
    activeDownloadId, 
    setActiveDownloadId
  } = useAppStore()
  
  // Get theme from next-themes
  const { theme } = useTheme()
  
  // TanStack Query hooks
  const validateUrlMutation = useValidateUrl()
  const startDownloadMutation = useStartDownload()
  const { data: downloadStatus } = useDownloadStatus(activeDownloadId)
  const { data: downloadHistory = [] } = useDownloadHistory()
  
  // Sync theme with Zustand store
  useEffect(() => {
    if (theme) {
      useAppStore.getState().setTheme(theme as 'light' | 'dark')
    }
  }, [theme])
  
  // Function to validate YouTube URL
  const validateUrl = async () => {
    if (!url) {
      toast.error('Please enter a YouTube URL')
      return
    }
    
    try {
      validateUrlMutation.mutate(url, {
        onSuccess: (data) => {
          setVideoInfo(data)
          toast.success('URL validated successfully')
        },
        onError: (error) => {
          toast.error(error instanceof Error ? error.message : 'Invalid YouTube URL')
        }
      })
    } catch {
      toast.error('Invalid YouTube URL')
    }
  }
  
  // Function to start download
  const startDownload = async () => {
    if (!videoInfo) return
    
    try {
      startDownloadMutation.mutate(url, {
        onSuccess: (data) => {
          setActiveDownloadId(data.id)
          toast.success('Download started')
        },
        onError: (error) => {
          toast.error(error instanceof Error ? error.message : 'Failed to start download')
        }
      })
    } catch {
      toast.error('Download failed')
    }
  }
  
  // Function to cancel download
  const cancelDownload = () => {
    setActiveDownloadId(null)
    toast.info('Download cancelled')
  }
  
  // Function to clear history
  const clearHistory = () => {
    // In a real app, this would call an API to clear history
    toast.info('History cleared')
  }
  
  // Function to download again from history
  const downloadAgain = (item: DownloadInfo) => {
    setUrl(item.url)
    setVideoInfo({
      id: item.id,
      title: item.title,
      thumbnail: item.thumbnail,
      url: item.url,
      duration: 0, // We don't have this in history
      author: '' // We don't have this in history
    })
    toast.success('Starting download again')
  }
  
  // Function to handle download completion
  const handleDownloadComplete = () => {
    // In actual implementation, this would download the file
    toast.success('MP3 downloaded successfully')
    setActiveDownloadId(null)
  }
  
  // Format seconds to MM:SS
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`
  }

  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      variants={fadeIn}
      className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 text-slate-900 dark:text-slate-50"
    >
      {/* Header */}
      <motion.header 
        variants={slideUp}
        className="container mx-auto px-4 py-6 flex justify-between items-center"
      >
        <div className="flex items-center gap-2">
          <motion.svg 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="h-6 w-6 text-sky-500 dark:text-sky-400"
            whileHover={{ scale: 1.2, rotate: 5 }}
            transition={{ type: "spring", stiffness: 400, damping: 10 }}
          >
            <path d="m12 8-9.04 9.06a2.82 2.82 0 1 0 3.98 3.98L16 12" />
            <circle cx="17" cy="7" r="5" />
          </motion.svg>
          <motion.span 
            className="text-xl font-bold bg-gradient-to-r from-sky-500 to-indigo-500 dark:from-sky-400 dark:to-indigo-400 text-transparent bg-clip-text"
            whileHover={{ scale: 1.05 }}
          >
            SoundStream
          </motion.span>
        </div>
        <ThemeToggle />
      </motion.header>

      {/* Hero Section */}
      <motion.section 
        variants={slideUp}
        className="container mx-auto px-4 py-16 md:py-24 text-center"
      >
        <motion.h1 
          className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-sky-500 to-indigo-500 dark:from-sky-400 dark:to-indigo-400 text-transparent bg-clip-text"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          Convert YouTube to MP3
        </motion.h1>
        <motion.p 
          className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          A sleek, high-performance tool to download your favorite YouTube videos as MP3 files. Fast, simple, and free.
        </motion.p>
        
        {/* URL Input */}
        <motion.div 
          className="max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
        >
          <div className="flex flex-col md:flex-row gap-4 p-1.5 bg-white/50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg">
            <Input 
              type="url" 
              placeholder="Paste YouTube URL here..." 
              className="flex-1 bg-transparent border-0 focus-visible:ring-0 focus-visible:ring-offset-0 text-slate-900 dark:text-slate-50"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={validateUrlMutation.isPending || !!activeDownloadId}
            />
            {!videoInfo ? (
              <Button 
                className="bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-600 hover:to-indigo-600 text-white"
                onClick={validateUrl}
                disabled={validateUrlMutation.isPending || !url}
              >
                {validateUrlMutation.isPending ? 'Validating...' : 'Validate URL'}
              </Button>
            ) : (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 500, damping: 15 }}
              >
                <Button 
                  className="bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-600 hover:to-indigo-600 text-white"
                  onClick={startDownload}
                  disabled={startDownloadMutation.isPending || !!activeDownloadId}
                >
                  {startDownloadMutation.isPending ? 'Starting...' : 'Download MP3'}
                </Button>
              </motion.div>
            )}
          </div>
        </motion.div>
      </motion.section>

      {/* Features */}
      <AnimatePresence>
        {!activeDownloadId && (!downloadHistory || downloadHistory.length === 0) && (
          <motion.section 
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            exit={{ opacity: 0, y: 20 }}
            className="container mx-auto px-4 py-16"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <motion.div variants={slideUp}>
                <Card className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
                  <CardHeader>
                    <motion.div 
                      className="w-12 h-12 rounded-lg bg-gradient-to-br from-sky-500 to-indigo-500 flex items-center justify-center mb-4"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    >
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="h-6 w-6 text-white"
                      >
                        <path d="M12 19V5" />
                        <path d="M5 12l7-7 7 7" />
                      </svg>
                    </motion.div>
                    <CardTitle>High-Quality Audio</CardTitle>
                    <CardDescription className="text-slate-600 dark:text-slate-400">
                      Get the best audio quality from your favorite YouTube videos
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>

              <motion.div variants={slideUp}>
                <Card className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
                  <CardHeader>
                    <motion.div 
                      className="w-12 h-12 rounded-lg bg-gradient-to-br from-sky-500 to-indigo-500 flex items-center justify-center mb-4"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    >
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="h-6 w-6 text-white"
                      >
                        <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                        <path d="m9 12 2 2 4-4" />
                      </svg>
                    </motion.div>
                    <CardTitle>Fast Processing</CardTitle>
                    <CardDescription className="text-slate-600 dark:text-slate-400">
                      Convert videos to MP3 in seconds with our optimized backend
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>

              <motion.div variants={slideUp}>
                <Card className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
                  <CardHeader>
                    <motion.div 
                      className="w-12 h-12 rounded-lg bg-gradient-to-br from-sky-500 to-indigo-500 flex items-center justify-center mb-4"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    >
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="h-6 w-6 text-white"
                      >
                        <path d="M12 2v8" />
                        <path d="m4.93 10.93 1.41 1.41" />
                        <path d="M2 18h2" />
                        <path d="M20 18h2" />
                        <path d="m19.07 10.93-1.41 1.41" />
                        <path d="M22 22H2" />
                        <path d="m16 6-4 4-4-4" />
                        <path d="M16 18a4 4 0 0 0 0-8H8a4 4 0 1 0 0 8" />
                      </svg>
                    </motion.div>
                    <CardTitle>Download History</CardTitle>
                    <CardDescription className="text-slate-600 dark:text-slate-400">
                      Keep track of your downloads with our session-based history
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Download Interface */}
      <AnimatePresence>
        {activeDownloadId && downloadStatus && videoInfo && (
          <motion.section 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="container mx-auto px-4 py-16"
          >
            <Card className="max-w-2xl mx-auto bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle>
                  {downloadStatus.status === 'completed' ? 'Download Complete' : 'Download in Progress'}
                </CardTitle>
                <CardDescription className="text-slate-600 dark:text-slate-400">
                  {downloadStatus.status === 'completed' 
                    ? 'Your MP3 file is ready' 
                    : 'Your MP3 file is being prepared'}
                </CardDescription>
              </CardHeader>
              
              {downloadStatus.status !== 'completed' ? (
                <>
                  <CardContent className="space-y-4">
                    <div className="flex gap-4">
                      <div className="w-40 h-24 bg-slate-200 dark:bg-slate-700 rounded-md overflow-hidden">
                        <div className="w-full h-full bg-gradient-to-br from-slate-300 to-slate-200 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center">
                          <svg 
                            xmlns="http://www.w3.org/2000/svg" 
                            viewBox="0 0 24 24" 
                            fill="none" 
                            stroke="currentColor" 
                            strokeWidth="2" 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            className="h-10 w-10 text-slate-400 dark:text-slate-500"
                          >
                            <path d="m22 8-6 4 6 4V8Z" />
                            <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
                          </svg>
                        </div>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium mb-1 line-clamp-2">{videoInfo.title}</h3>
                        <div className="flex gap-3 text-sm text-slate-600 dark:text-slate-400 mb-2">
                          <span>{formatDuration(videoInfo.duration)}</span>
                          <span>{videoInfo.author}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>
                          {downloadStatus.status === 'processing' ? 'Processing audio...' : 
                           downloadStatus.status === 'downloading' ? 'Downloading...' : 
                           'Preparing download...'}
                        </span>
                        <span className="text-sky-500 dark:text-sky-400">{downloadStatus.progress}%</span>
                      </div>
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${downloadStatus.progress}%` }}
                        transition={{ duration: 0.5 }}
                      >
                        <Progress value={downloadStatus.progress} className="h-2 bg-slate-200 dark:bg-slate-700" />
                      </motion.div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end gap-3">
                    <Button 
                      variant="outline" 
                      className="border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-50 hover:bg-slate-100 dark:hover:bg-slate-700"
                      onClick={cancelDownload}
                    >
                      Cancel
                    </Button>
                  </CardFooter>
                </>
              ) : (
                <CardContent className="space-y-6 text-center">
                  <motion.div 
                    className="w-16 h-16 mx-auto rounded-full bg-sky-500/20 flex items-center justify-center"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ 
                      type: "spring", 
                      stiffness: 300, 
                      damping: 20,
                      delay: 0.2
                    }}
                  >
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="h-8 w-8 text-sky-500 dark:text-sky-400"
                    >
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                      <path d="m9 11 3 3L22 4" />
                    </svg>
                  </motion.div>
                  <motion.h3 
                    className="text-xl font-medium"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                  >
                    {videoInfo.title}
                  </motion.h3>
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                  >
                    <motion.div className="inline-block" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button 
                        className="bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-600 hover:to-indigo-600 text-white"
                        onClick={handleDownloadComplete}
                      >
                        Download MP3
                      </Button>
                    </motion.div>
                  </motion.div>
                </CardContent>
              )}
            </Card>
          </motion.section>
        )}
      </AnimatePresence>

      {/* History Section */}
      <AnimatePresence>
        {downloadHistory && downloadHistory.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ delay: 0.2 }}
          >
            <HistorySection 
              downloadHistory={downloadHistory}
              onClearHistory={clearHistory}
              onDownloadAgain={downloadAgain}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <motion.footer 
        variants={fadeIn}
        className="container mx-auto px-4 py-8 border-t border-slate-200 dark:border-slate-800 text-center text-slate-600 dark:text-slate-400 text-sm"
      >
        <p>© 2025 SoundStream. All rights reserved.</p>
      </motion.footer>
    </motion.div>
  );
}

// Type definition for DownloadInfo
interface DownloadInfo {
  id: string
  title: string
  thumbnail: string
  url: string
  download_path: string
  timestamp: string
  status: 'processing' | 'downloading' | 'completed' | 'failed'
  progress: number
}
