'use client'

import { useState, useEffect } from 'react'
import { Toaster } from "@/components/ui/sonner"
import { ThemeProvider } from 'next-themes'
import { QueryProvider } from './query-provider'

export function Providers({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false)

  // Prevent hydration mismatch by only rendering after mount
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <QueryProvider>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <Toaster />
        {children}
      </ThemeProvider>
    </QueryProvider>
  )
}
