'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

// Define types for our API responses
interface VideoInfo {
  id: string
  title: string
  thumbnail: string
  url: string
  duration: number
  author: string
}

interface DownloadInfo {
  id: string
  title: string
  thumbnail: string
  url: string
  download_path: string
  timestamp: string
  status: 'processing' | 'downloading' | 'completed' | 'failed'
  progress: number
}

// Get the API base URL based on environment
const getApiBaseUrl = () => {
  // When running locally, frontend is on port 3000 and backend on port 8000
  // When deployed, we need to use the exposed backend URL
  const isProduction = typeof window !== 'undefined' && window.location.hostname.includes('manus.computer');
  
  if (isProduction) {
    // Extract the subdomain pattern and replace the port
    const hostname = window.location.hostname;
    const subdomainBase = hostname.split('-').slice(1).join('-');
    return `https://8000-${subdomainBase}`;
  }
  
  return 'http://localhost:8000';
};

// API client functions
const api = {
  validateUrl: async (url: string): Promise<VideoInfo> => {
    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/api/validate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.detail || 'Failed to validate URL')
    }
    
    return response.json()
  },
  
  startDownload: async (url: string): Promise<DownloadInfo> => {
    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/api/download`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.detail || 'Failed to start download')
    }
    
    return response.json()
  },
  
  getDownloadStatus: async (downloadId: string): Promise<DownloadInfo> => {
    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/api/status/${downloadId}`)
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.detail || 'Failed to check download status')
    }
    
    return response.json()
  },
  
  getDownloadHistory: async (): Promise<DownloadInfo[]> => {
    const baseUrl = getApiBaseUrl();
    const response = await fetch(`${baseUrl}/api/history`)
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.detail || 'Failed to get download history')
    }
    
    return response.json()
  }
}

// Custom hooks using TanStack Query
export function useValidateUrl() {
  return useMutation({
    mutationFn: api.validateUrl,
    onError: (error) => {
      console.error('Error validating URL:', error)
    }
  })
}

export function useStartDownload() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: api.startDownload,
    onSuccess: () => {
      // Invalidate download history query to refetch
      queryClient.invalidateQueries({ queryKey: ['downloadHistory'] })
    },
    onError: (error) => {
      console.error('Error starting download:', error)
    }
  })
}

export function useDownloadStatus(downloadId: string | null) {
  return useQuery({
    queryKey: ['downloadStatus', downloadId],
    queryFn: () => api.getDownloadStatus(downloadId!),
    enabled: !!downloadId, // Only run query if downloadId is provided
    refetchInterval: 1000, // Poll every second
    select: (data) => data, // Return data as is
    refetchIntervalInBackground: true // Continue polling even when tab is not active
  })
}

export function useDownloadHistory() {
  return useQuery({
    queryKey: ['downloadHistory'],
    queryFn: api.getDownloadHistory,
    staleTime: 30000, // Consider data fresh for 30 seconds
  })
}
