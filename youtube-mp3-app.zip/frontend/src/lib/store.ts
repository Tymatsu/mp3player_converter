'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// Define types for our store
interface VideoInfo {
  id: string
  title: string
  thumbnail: string
  url: string
  duration: number
  author: string
}

interface AppState {
  // URL input state
  url: string
  setUrl: (url: string) => void
  
  // Video info state
  videoInfo: VideoInfo | null
  setVideoInfo: (videoInfo: VideoInfo | null) => void
  
  // Active download state
  activeDownloadId: string | null
  setActiveDownloadId: (downloadId: string | null) => void
  
  // Theme state
  theme: 'light' | 'dark'
  toggleTheme: () => void
  setTheme: (theme: 'light' | 'dark') => void
  
  // Reset state
  resetState: () => void
}

// Create store with persist middleware for theme preference
export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // URL input state
      url: '',
      setUrl: (url) => set({ url }),
      
      // Video info state
      videoInfo: null,
      setVideoInfo: (videoInfo) => set({ videoInfo }),
      
      // Active download state
      activeDownloadId: null,
      setActiveDownloadId: (downloadId) => set({ activeDownloadId: downloadId }),
      
      // Theme state
      theme: 'dark',
      toggleTheme: () => set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),
      setTheme: (theme) => set({ theme }),
      
      // Reset state
      resetState: () => set({ 
        url: '', 
        videoInfo: null, 
        activeDownloadId: null 
      }),
    }),
    {
      name: 'youtube-mp3-app-storage',
      partialize: (state) => ({ theme: state.theme }), // Only persist theme
    }
  )
)
