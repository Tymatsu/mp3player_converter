'use client'

import { motion } from 'framer-motion'
import { useTheme } from 'next-themes'
import { useAppStore } from '@/lib/store'
import { useEffect } from 'react'

interface ThemeToggleProps {
  className?: string
}

export function ThemeToggle({ className }: ThemeToggleProps) {
  const { theme, setTheme } = useTheme()
  const toggleTheme = useAppStore(state => state.toggleTheme)
  
  // Sync theme changes with Zustand store
  useEffect(() => {
    if (theme) {
      useAppStore.getState().setTheme(theme as 'light' | 'dark')
    }
  }, [theme])

  const handleToggle = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark'
    setTheme(newTheme)
    toggleTheme()
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <span className="text-sm text-slate-600 dark:text-slate-400">Dark Mode</span>
      <motion.button
        onClick={handleToggle}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-white ${
          theme === 'dark' 
            ? 'bg-sky-500' 
            : 'bg-slate-200'
        }`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <motion.span
          className="inline-block h-4 w-4 rounded-full bg-white"
          initial={false}
          animate={{
            translateX: theme === 'dark' ? 24 : 4,
          }}
          transition={{
            type: "spring",
            stiffness: 500,
            damping: 30
          }}
        />
      </motion.button>
    </div>
  )
}
