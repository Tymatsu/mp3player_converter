'use client'

import { motion } from 'framer-motion'
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface DownloadInfo {
  id: string
  title: string
  thumbnail: string
  url: string
  download_path: string
  timestamp: string
  status: 'processing' | 'downloading' | 'completed' | 'failed'
  progress: number
}

interface HistorySectionProps {
  downloadHistory: DownloadInfo[]
  onClearHistory: () => void
  onDownloadAgain: (item: DownloadInfo) => void
}

export function HistorySection({ 
  downloadHistory, 
  onClearHistory, 
  onDownloadAgain 
}: HistorySectionProps) {
  if (downloadHistory.length === 0) return null

  return (
    <section className="container mx-auto px-4 py-16">
      <div className="flex justify-between items-center mb-8">
        <motion.h2 
          className="text-2xl md:text-3xl font-bold"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          Download History
        </motion.h2>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button 
            variant="ghost" 
            className="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-50"
            onClick={onClearHistory}
          >
            Clear History
          </Button>
        </motion.div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {downloadHistory.map((item, index) => (
          <motion.div 
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              delay: index * 0.1,
              type: "spring",
              stiffness: 260,
              damping: 20
            }}
            whileHover={{ 
              y: -5,
              transition: { duration: 0.2 }
            }}
          >
            <Card className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 overflow-hidden">
              <motion.div 
                className="h-40 bg-gradient-to-br from-slate-300 to-slate-200 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center"
                whileHover={{ 
                  backgroundColor: "#0ea5e9",
                  transition: { duration: 0.3 }
                }}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="h-12 w-12 text-slate-400 dark:text-slate-500"
                >
                  <path d="m22 8-6 4 6 4V8Z" />
                  <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
                </svg>
              </motion.div>
              <CardContent className="p-4">
                <h3 className="font-medium mb-1 line-clamp-2">{item.title}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
                  Downloaded on {new Date(item.timestamp).toLocaleDateString()}
                </p>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    variant="ghost" 
                    className="text-sky-500 dark:text-sky-400 hover:text-sky-600 dark:hover:text-sky-300 p-0 h-auto"
                    onClick={() => onDownloadAgain(item)}
                  >
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="h-4 w-4 mr-1"
                    >
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                      <polyline points="7 10 12 15 17 10" />
                      <line x1="12" x2="12" y1="15" y2="3" />
                    </svg>
                    Download Again
                  </Button>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
