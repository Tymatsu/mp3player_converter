'use client'

import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

interface VideoInfo {
  id: string
  title: string
  thumbnail: string
  url: string
  duration: number
  author: string
}

interface DownloadCardProps {
  videoInfo: VideoInfo
  onDownload: () => void
  onCancel: () => void
  downloadProgress: number
  downloadStatus: 'processing' | 'downloading' | 'completed' | 'failed'
}

export function DownloadCard({ 
  videoInfo, 
  onDownload, 
  onCancel, 
  downloadProgress, 
  downloadStatus 
}: DownloadCardProps) {
  // Format seconds to MM:SS
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`
  }

  return (
    <Card className="max-w-2xl mx-auto bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
      <CardHeader>
        <CardTitle>
          {downloadStatus === 'completed' ? 'Download Complete' : 'Download in Progress'}
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-400">
          {downloadStatus === 'completed' 
            ? 'Your MP3 file is ready' 
            : 'Your MP3 file is being prepared'}
        </CardDescription>
      </CardHeader>
      
      {downloadStatus !== 'completed' ? (
        <>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <div className="w-40 h-24 bg-slate-200 dark:bg-slate-700 rounded-md overflow-hidden">
                <div className="w-full h-full bg-gradient-to-br from-slate-300 to-slate-200 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="h-10 w-10 text-slate-400 dark:text-slate-500"
                  >
                    <path d="m22 8-6 4 6 4V8Z" />
                    <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
                  </svg>
                </div>
              </div>
              <div className="flex-1">
                <h3 className="font-medium mb-1 line-clamp-2">{videoInfo.title}</h3>
                <div className="flex gap-3 text-sm text-slate-600 dark:text-slate-400 mb-2">
                  <span>{formatDuration(videoInfo.duration)}</span>
                  <span>{videoInfo.author}</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>
                  {downloadStatus === 'processing' ? 'Processing audio...' : 
                   downloadStatus === 'downloading' ? 'Downloading...' : 
                   downloadStatus === 'failed' ? 'Download failed' :
                   'Preparing download...'}
                </span>
                <span className="text-sky-500 dark:text-sky-400">{downloadProgress}%</span>
              </div>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${downloadProgress}%` }}
                transition={{ duration: 0.5 }}
              >
                <Progress value={downloadProgress} className="h-2 bg-slate-200 dark:bg-slate-700" />
              </motion.div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end gap-3">
            <Button 
              variant="outline" 
              className="border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-50 hover:bg-slate-100 dark:hover:bg-slate-700"
              onClick={onCancel}
            >
              Cancel
            </Button>
          </CardFooter>
        </>
      ) : (
        <CardContent className="space-y-6 text-center">
          <motion.div 
            className="w-16 h-16 mx-auto rounded-full bg-sky-500/20 flex items-center justify-center"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ 
              type: "spring", 
              stiffness: 300, 
              damping: 20,
              delay: 0.2
            }}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="h-8 w-8 text-sky-500 dark:text-sky-400"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <path d="m9 11 3 3L22 4" />
            </svg>
          </motion.div>
          <motion.h3 
            className="text-xl font-medium"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            {videoInfo.title}
          </motion.h3>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <motion.div className="inline-block" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button 
                className="bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-600 hover:to-indigo-600 text-white"
                onClick={onDownload}
              >
                Download MP3
              </Button>
            </motion.div>
          </motion.div>
        </CardContent>
      )}
    </Card>
  )
}
